from __future__ import absolute_import

# import apis into api package
from .mnist_api import MNISTApi
from .mnist_predictor_api import MNISTPredictorApi
